# Boulevard

This mod adds a moon called Boulevard. This moon is designed after the map ttt_67thway from the game Garry's Mod.

It's meant to be a high risk, slightly higher reward free moon for those who like the Mansion map and high enemy spawn rates.

This is my first map, extremely WIP as there will be buildings and things outside the walls to not make it feel so empty.

HUGE Shoutout to Audio Knight/Starlancer for his video tutorial on how to make custom moons, truly a goat in the community.