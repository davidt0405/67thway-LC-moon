### Update 1.0.2:

* Credited Audio Knight/Starlancer for his moon creation tutorial
* Shortened level description so it doesn't overflow the monitor
* Added the house building, currently nothing inside of it but that will probably change in the future, for now use it to just hide from the mass amounts of enemies.

### Update 1.0.0:

* Map uploaded to Thunderstore